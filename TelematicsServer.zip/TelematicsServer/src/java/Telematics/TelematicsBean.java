
package Telematics;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import httpdemo.server.HttpServerDemo;

public class TelematicsBean {
  private String user;
  private String pass;
  private Connection con;
  private Statement stmt;
  private ResultSet rs;
   
public TelematicsBean()
  {
   try{  
        Class.forName("com.mysql.jdbc.Driver");  
        con=DriverManager.getConnection("jdbc:mysql://localhost:3306/TelematicsWeb","root",""); 
        System.out.println("my database is connected ");
 
        stmt=con.createStatement();  
        
        //runServer();

      }
        catch(Exception e3){ 
            e3.printStackTrace();
       }  
  }
    public String getUser() {
        return user;
    }
    public void setUser(String user) {
        this.user = user;
    }
    public String getPass() {
        return pass;
    }
    public void setPass(String pass) {
        this.pass = pass;
    }
    
    public void runServer(){
        HttpServerDemo http=new HttpServerDemo();
        
        boolean b1Result=http.open(1000);
        
        if(b1Result)
        {
           System.out.println("Server started");
        }
        else
        {
          System.out.println("Server start error");
        }
        http.stop();
        
    }
    public boolean valid(){
       
       boolean t=false;
               
       try {
        ResultSet rs=stmt.executeQuery("select * from login where Username='"+user+"' and "+"Password='"+pass+"'");    
        
        if(rs.next())
        {
            t=true;
            System.out.println(rs.getString(1)+"    "+rs.getString(2) );
            con.close();
        }
        else
            t=false;
 
       }
       catch (Exception ex3) {
           ex3.printStackTrace();
       }
  
       return t;
     }   
     
  }

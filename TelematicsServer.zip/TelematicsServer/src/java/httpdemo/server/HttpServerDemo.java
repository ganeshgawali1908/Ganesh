package httpdemo.server;

// import org.apache.log4j.Logger;
import com.sun.net.httpserver.HttpServer;
import java.net.InetAddress;
import java.net.InetSocketAddress;

public class HttpServerDemo {
    
    // creatig a new http server variable
    private HttpServer mhttpserver=null;
    
    // creating a new functio let open http server by port
    public boolean open(int iPort)
    {
       boolean b1Result=false;
      
       try{
           // creating a new server on port
            this.mhttpserver=HttpServer.create(new InetSocketAddress(iPort), 0);
            
            // start handler let get request from http client
            this.mhttpserver.createContext("/LocationSharing",new RequestHandler());
            this.mhttpserver.createContext("/RemoteCarControl",new RequestHandler());
            this.mhttpserver.createContext("/VehicleDiagnostics",new RequestHandler());
            
            // set http executor default
            this.mhttpserver.setExecutor(null);

            // stating http server
            this.mhttpserver.start();
            b1Result=true;
       }
       catch(Exception e)
       {
          e.printStackTrace();        
       }
       return b1Result; 
    }
    // stop http server
    public void stop()
    { 
      if(this.mhttpserver != null){
      this.mhttpserver.stop(20000);
      }
    }
    
}

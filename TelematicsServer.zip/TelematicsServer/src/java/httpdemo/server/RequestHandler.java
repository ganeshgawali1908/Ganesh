
package httpdemo.server;

import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;
import java.io.IOException;
import java.io.InputStream;
import java.net.URI;

class MyThread extends Thread{
    URI uri;
    String query= uri.getQuery();
    
    MyThread(URI uri){
        this.uri = uri;
    }
    public void run(){
        if(query.equalsIgnoreCase("/LocationSharing")){ 
            System.out.println("Location Sharing URI");
        }
        else if(query.equalsIgnoreCase("/RemoteCarControl")){ 
            System.out.println("Remote Car Control URI");
        }
        else if(query.equalsIgnoreCase("/VehicleDiagnostics")){ 
            System.out.println("Vehicl Diagnostics URI");
        }
    }
}
// creating http handler let receiver all request from http client
public class RequestHandler implements HttpHandler{
    @Override
    public void handle(HttpExchange he) throws IOException {
        
        URI uri = he.getRequestURI();
        MyThread t = new MyThread(uri);
        t.start();
        
        // here u ca handle request from client 
        
        System.out.println(he.getRequestMethod()+ "\r\n");
        InputStream in = he.getRequestBody();
        int iAvailable = in.available();
        while(iAvailable > 0)
        {
           byte[] btBuffer = new byte[iAvailable];
           int iByteRead = in.read(btBuffer, 0, btBuffer.length);
           
           iAvailable=iAvailable-iByteRead;
           System.out.println(new String(btBuffer) + "\r\n");
        }
        System.out.println("Finished");
        
        
    }
    
}

package com.example.telematicsapp;

import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.AsyncTask;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import static com.example.telematicsapp.MainActivity.ipx;

public class LocationSharingActivity extends AppCompatActivity implements LocationListener{

    private Context context;
    public Button getLocationBtn;
    private Button getShareLocationBtngmap;
    private TextView locationText,datex,timex;
    private LocationManager locationManager;
    public Double src_lat;
    public Double src_lon;
    public Double dest_lat;
    public Double dest_lon;

    public static String addre;

    private static final String dbt_url="jdbc:mysql://"+ipx+":3306/telematicsweb";
    private static final String user="root";
    private static final String pwd="";

    public String date_n = new SimpleDateFormat("MMM dd, yyyy", Locale.getDefault()).format(new Date());

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_location_sharing);

        getLocationBtn = (Button) findViewById(R.id.btn_currentlocation);
        locationText = (TextView) findViewById(R.id.txt_location);
        datex = (TextView) findViewById(R.id.date);
        timex = (TextView) findViewById(R.id.clock);
        getShareLocationBtngmap = (Button) findViewById(R.id.btn_sharelocationgmap);

        datex.setText(date_n);

        context = this;

        if (ContextCompat.checkSelfPermission(context, android.Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(getApplicationContext(), android.Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {

            ActivityCompat.requestPermissions(this, new String[]{
                    android.Manifest.permission.ACCESS_FINE_LOCATION, android.Manifest.permission.ACCESS_COARSE_LOCATION}, 101);

        }

        getLocationBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getLocation();
            }
        });

        getShareLocationBtngmap.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent share = new Intent(android.content.Intent.ACTION_SEND);
                share.setType("text/plain");
                share.addFlags(Intent.FLAG_ACTIVITY_CLEAR_WHEN_TASK_RESET);
                share.putExtra(Intent.EXTRA_SUBJECT, "Title Of The Post");
                share.putExtra(Intent.EXTRA_TEXT, "http://maps.google.com/maps?saddr=" + src_lat+ "," + src_lon + "&daddr=" + dest_lat+"," + dest_lon);
                startActivity(Intent.createChooser(share, "Share!"));

                Send send = new Send();
                send.execute();

            }

        });
    }


    private void getLocation() {

        try {
            locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
            locationManager.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 500, 5, (LocationListener) this);
        }
        catch(SecurityException e) {
            e.printStackTrace();
        }
    }


    @Override
    public void onLocationChanged(Location location) {

        src_lat = location.getLatitude();
        src_lon = location.getLongitude();

        locationText.setText("Latitude: " +src_lat+ "\n Longitude: " + src_lon);

        dest_lat = src_lat;
        dest_lon = src_lon;


        try {
            Geocoder geocoder = new Geocoder(this, Locale.getDefault());
            List<Address> addresses = geocoder.getFromLocation(location.getLatitude(), location.getLongitude(), 1);
            locationText.setText(locationText.getText() + "\n"+addresses.get(0).getAddressLine(0)+", "+
                    addresses.get(0).getAddressLine(1)+", "+addresses.get(0).getAddressLine(2));

            addre=(addresses.get(0).getAddressLine(0)+", "+addresses.get(0).getAddressLine(1)+", "+addresses.get(0).getAddressLine(2));

        }
        catch(Exception e)
        {

        }

    }

    @Override
    public void onStatusChanged(String provider, int status, Bundle extras) {

        Toast.makeText(context, "Please Enable GPS and Internet", Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onProviderEnabled(String provider) {

    }

    @Override
    public void onProviderDisabled(String provider) {

    }


    private class Send extends AsyncTask<String ,String,String>
    {
        String msg ="";
        @Override
        protected String doInBackground(String... strings)
        {
            String timesave=timex.getText().toString();
            String dtesave=datex.getText().toString();
            String lat=src_lat.toString();
            String lon=src_lon.toString();

            try
            {
                Class.forName("com.mysql.jdbc.Driver");
                Connection connn = DriverManager.getConnection(dbt_url,user,pwd);

                if(connn == null)
                {
                    //toastMessage("Data Not Inserted!");
                }
                else
                {
                    String sql= "INSERT INTO locationsharing (Date, Timestamp, Latitude, Longitude, Location_From) VALUES ('"+dtesave+"','"+timesave+"','"+lat+"','"+lon+"','"+addre+"')";
                    Statement stmt = connn.createStatement();
                    stmt.executeUpdate(sql);

                }
            }
            catch (Exception e)
            {
                Toast.makeText(getApplicationContext(),"Connection goes Wrong",Toast.LENGTH_SHORT).show();
                e.printStackTrace();
            }

            return msg;
        }

        @Override
        protected void onPostExecute(String msg) {

        }
    }


}

package com.example.telematicsapp;

import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

import static com.example.telematicsapp.MainActivity.ipx;


public class RemoteCarControlActivity extends AppCompatActivity {


    private Button startbtn;
    private Button stopbtn;
    private TextView datex,timex;


    private static final String dbt_url="jdbc:mysql://"+ipx+":3306/telematicsweb";
    private static final String user="root";
    private static final String pwd="";

    public int enginestate;

    FirebaseDatabase database;
    DatabaseReference databaseReference;

    public String date_n = new SimpleDateFormat("MMM dd, yyyy", Locale.getDefault()).format(new Date());

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_remote_car_control);

        startbtn = findViewById(R.id.btn_start);
        stopbtn = findViewById(R.id.btn_stop);
        datex = (TextView) findViewById(R.id.date);
        timex = (TextView) findViewById(R.id.clock);

        database = FirebaseDatabase.getInstance();
        databaseReference = database.getReference("EngineState");

        datex.setText(date_n);

        startbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(RemoteCarControlActivity.this, "Motor Start", Toast.LENGTH_SHORT).show();
                databaseReference.setValue(1);

                Send1 send = new Send1();
                send.execute();

            }
        });

        stopbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(RemoteCarControlActivity.this, "Motor Stop", Toast.LENGTH_SHORT).show();
                databaseReference.setValue(0);

                Send2 send2 = new Send2();
                send2.execute();
            }
        });

    }

    private class Send1 extends AsyncTask<String ,String,String>
    {
        String msg ="";
        @Override
        protected String doInBackground(String... strings)
        {
            String timesave=timex.getText().toString();
            String dtesave=datex.getText().toString();

            try
            {
                Class.forName("com.mysql.jdbc.Driver");
                Connection connn = DriverManager.getConnection(dbt_url,user,pwd);

                if(connn == null)
                {
                    //toastMessage("Data Not Inserted!");
                }
                else
                {
                    String sql= "INSERT INTO remotecarcontrol (Date, Timestamp, EngineState) VALUES ('"+dtesave+"','"+timesave+"','"+"Start"+"')";
                    Statement stmt = connn.createStatement();
                    stmt.executeUpdate(sql);

                }
            }
            catch (Exception e)
            {
                Toast.makeText(getApplicationContext(),"Connection goes Wrong",Toast.LENGTH_SHORT).show();
                e.printStackTrace();
            }

            return msg;
        }

        @Override
        protected void onPostExecute(String msg) {

        }
    }

    private class Send2 extends AsyncTask<String ,String,String>
    {
        String msg ="";
        @Override
        protected String doInBackground(String... strings)
        {
            String timesave=timex.getText().toString();
            String dtesave=datex.getText().toString();

            try
            {
                Class.forName("com.mysql.jdbc.Driver");
                Connection connn = DriverManager.getConnection(dbt_url,user,pwd);

                if(connn == null)
                {
                    //toastMessage("Data Not Inserted!");
                }
                else
                {
                    String sql= "INSERT INTO remotecarcontrol (Date, Timestamp, EngineState) VALUES ('"+dtesave+"','"+timesave+"','"+"Stop"+"')";
                    Statement stmt = connn.createStatement();
                    stmt.executeUpdate(sql);

                }
            }
            catch (Exception e)
            {
                Toast.makeText(getApplicationContext(),"Connection goes Wrong",Toast.LENGTH_SHORT).show();
                e.printStackTrace();
            }

            return msg;
        }

        @Override
        protected void onPostExecute(String msg) {

        }
    }
}

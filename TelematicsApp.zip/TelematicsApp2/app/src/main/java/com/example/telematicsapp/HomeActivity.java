package com.example.telematicsapp;

import android.content.Context;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class HomeActivity extends AppCompatActivity {

    private Context context;
    private Button txtlocation;
    private Button txtremotecar;
    private Button txtvehiclediagn;
    private Intent intent;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        init();
    }

    private void init() {

        context = this;

        txtlocation = (Button) findViewById(R.id.txt_loc_share);
        txtremotecar = (Button) findViewById(R.id.txt_remote_car);
        txtvehiclediagn = (Button) findViewById(R.id.txt_veh_diagn);

        setclick();
    }

    private void setclick() {

        txtlocation.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                intent =new Intent(context,LocationSharingActivity.class);
                startActivity(intent);
            }
        });


        txtremotecar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                intent =new Intent(context,RemoteCarControlActivity.class);
                startActivity(intent);
            }
        });

        txtvehiclediagn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                intent =new Intent(context,VehicleDiagnosticsActivity.class);
                startActivity(intent);
            }
        });
    }

}

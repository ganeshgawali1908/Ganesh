package com.example.telematicsapp;

import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.net.HttpURLConnection;
import java.net.URL;

public class MainActivity extends AppCompatActivity {

    private Context context;
    private EditText edituser, editpass;
    private Button btnsbmt;
    private Intent intent;
    public EditText edtip;
    public static String ipx;

    String url = "https://192.168.43.121:17000/TelematicsServer/index.jsp";

    String user = "";
    String pass = "";

    SendHttpRequest t;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        context = this;

        edituser = findViewById(R.id.edt_user);
        editpass = findViewById(R.id.edt_pass);

        user = edituser.getText().toString();
        pass = editpass.getText().toString();
        btnsbmt = findViewById(R.id.btn_sbmt);

        edtip = findViewById(R.id.edit_ip);

        if(!edtip.getText().equals(null))
        {
            btnsbmt.setEnabled(true);
        }


        btnsbmt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                valid();
            }
        });


       // t = new SendHttpRequest();

//         String[] params = new String[]{url, "123"};
//         t.execute(params);
    }

    private boolean valid() {

        boolean x = true;

        ipx = edtip.getText().toString();

        if (edituser.getText().length() == 0) {

            Toast.makeText(context, "Username is mandatory", Toast.LENGTH_SHORT).show();
            x = false;

        }
        else if (editpass.getText().length() == 0) {
            Toast.makeText(context, "Password is mandatory", Toast.LENGTH_SHORT).show();
            x = false;
        }

        else if (edituser.getText().toString().equalsIgnoreCase("admin") && editpass.getText().toString().equalsIgnoreCase("admin")&& ipx.length()!=0) {

            Toast.makeText(context, "Login Successful", Toast.LENGTH_SHORT).show();

            intent = new Intent(context, HomeActivity.class);
            startActivity(intent);

            x = true;
        }

        else if(edtip.getText().toString().length()==0){
            Toast.makeText(this, "Enter ip address", Toast.LENGTH_SHORT).show();
        }

        else {
            Toast.makeText(context, "Invalid username and password or Enter ip address", Toast.LENGTH_SHORT).show();
        }


        return x;
    }

    public class SendHttpRequest extends AsyncTask<String, Void, String> {

        private String TAG = "MainActivity";

        @Override
        protected String doInBackground(String... params) {
            Log.d(TAG, "doInBackground: " + params);
            url = params[0];
            String name = "123";

            String data = sendHttpRequest(url, name);
            System.out.println("Data [" + data + "]");
            return data;
        }

        @Override
        protected void onPostExecute(String result) {
            Log.d(TAG, "onPostExecute: " + result);
        }

        String sendHttpRequest(String url, String name) {
            StringBuffer buffer = new StringBuffer();


            try {
                System.out.println("URL [" + url + "] - Name [" + name + "]");

                HttpURLConnection con = (HttpURLConnection) (new URL(url)).openConnection();
                con.setRequestMethod("POST");
                con.setDoInput(true);
                con.setDoOutput(true);
                con.connect();
                con.getOutputStream().write(("name=" + name).getBytes());

                con.disconnect();
            } catch (Throwable t) {
                t.printStackTrace();
            }

            return buffer.toString();
        }
    }
}



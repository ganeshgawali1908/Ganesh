package com.example.telematicsapp;

import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

import static com.example.telematicsapp.MainActivity.ipx;

public class VehicleDiagnosticsActivity extends AppCompatActivity {

    private TextView datex, timex;
    private Button str1btn;
    private EditText editResult;

    private static final String dbt_url = "jdbc:mysql://" + ipx + ":3306/telematicsweb";
    private static final String user = "root";
    private static final String pwd = "";

    public String date_n = new SimpleDateFormat("MMM dd, yyyy", Locale.getDefault()).format(new Date());

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_vehicle_diagnostics);

        datex = (TextView) findViewById(R.id.date);
        timex = (TextView) findViewById(R.id.clock);

        str1btn = findViewById(R.id.btn_str1);

        editResult = findViewById(R.id.edt_result);

        datex.setText(date_n);

        str1btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
            editResult.setText("Fuel:-50%"+"\n"+"Air Pressure:- Normal"+"\n"+"Distance:- 200km");
            Send send = new Send();
            send.execute();
                Toast.makeText(VehicleDiagnosticsActivity.this, "data inserted", Toast.LENGTH_SHORT).show();
            }
        });

    }

    private class Send extends AsyncTask<String, String, String> {
        String msg = "";

        @Override
        protected String doInBackground(String... strings) {
            String timesave = timex.getText().toString();
            String dtesave = datex.getText().toString();


            try {
                Class.forName("com.mysql.jdbc.Driver");
                Connection connn = DriverManager.getConnection(dbt_url, user, pwd);

                if (connn == null) {
                    //toastMessage("Data Not Inserted!");
                } else {
                    String sql = "INSERT INTO vehiclediagnostics (Date, Timestamp, Result) VALUES ('" + dtesave + "','" + timesave + "','" + "Fuel:-50%"+"\n"+"Air Pressure:- Normal"+"\n"+"Distance:- 200km" + "')";
                    Statement stmt = connn.createStatement();
                    stmt.executeUpdate(sql);

                }
            } catch (Exception e) {
                Toast.makeText(getApplicationContext(), "Connection goes Wrong", Toast.LENGTH_SHORT).show();
                e.printStackTrace();
            }

            return msg;
        }

        @Override
        protected void onPostExecute(String msg) {

        }

        @Override
        protected void onProgressUpdate(String... values) {
            Toast.makeText(getApplicationContext(), values[0], Toast.LENGTH_SHORT).show();
        }
    }
}